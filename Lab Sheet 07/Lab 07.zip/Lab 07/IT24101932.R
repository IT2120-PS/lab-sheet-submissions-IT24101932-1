setwd("C:\\Users\\My\\OneDrive\\Desktop\\Lab 07")
p1 <- punif(10, min=0, max=30)  
p2 <- 1 - punif(20, min=0, max=30)  
p1; p2

# Q2: 

lambda <- 1/2
p1 <- pexp(3, rate=lambda)
p2 <- 1 - pexp(4, rate=lambda)
p3 <- pexp(4, rate=lambda) - pexp(2, rate=lambda)
p1; p2; p3

# Q3: Normal distribution
mu <- 36.8
sigma <- 0.4

p1 <- 1 - pnorm(37.9, mean=mu, sd=sigma)
p2 <- pnorm(36.9, mean=mu, sd=sigma) - pnorm(36.4, mean=mu, sd=sigma)
T1 <- qnorm(0.012, mean=mu, sd=sigma)
T2 <- qnorm(0.99, mean=mu, sd=sigma)
p1; p2; T1; T2

# Exercise Q1
p_train <- punif(25, min=0, max=40) - punif(10, min=0, max=40)
p_train

# Exercise Q2
lambda <- 1/3
p_update <- pexp(2, rate=lambda)
p_update

# Exercise Q3

mu <- 100; sigma <- 15
p_iq <- 1 - pnorm(130, mean=mu, sd=sigma)
p_iq <- qnorm(0.95, mean=mu, sd=sigma)
p_iq; q_iq
