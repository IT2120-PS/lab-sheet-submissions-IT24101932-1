setwd("C:\\Users\\My\\OneDrive\\Desktop\\Lab -09")
#Q1
# Data
memes <- c(3, 7, 11, 0, 7, 0, 4, 5, 6, 2)

# One sample t-test
t.test(memes, mu = 3)

#Q2
# Data
mice <- c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)

# One-sided t-test
t.test(mice, mu = 25, alternative = "less")

# Extract details
result <- t.test(mice, mu = 25, alternative = "less")
result$statistic   
result$p.value     
result$conf.int    


#Q3
set.seed(123) # for reproducibility

# Generate 30 random sugar levels
sugar <- rnorm(30, mean = 9.8, sd = 0.05)

# One-sided t-test
t.test(sugar, mu = 10, alternative = "greater")
